"""Stage 3 - Similarity search: hand-written TF-IDF + cosine (no dependencies)."""
import math
import re
from collections import Counter


def normalize(text: str) -> str:
    """Strip volatile details so 'KeyError: user_17' and 'KeyError: user_42' look alike."""
    text = re.sub(r"0x[0-9a-fA-F]+", " ADDR ", text)
    text = re.sub(r"(['\"]).*?\1", " QUOTED ", text)
    text = re.sub(r"(/[\w.\-]+)+", " PATH ", text)
    text = re.sub(r"\d+", " N ", text)
    return text.lower()


def tokenize(text: str):
    return re.findall(r"[a-z_]{2,}", normalize(text))


class TfidfIndex:
    def __init__(self, docs):
        self.docs = [Counter(tokenize(d)) for d in docs]
        n = len(self.docs)
        df = Counter(t for d in self.docs for t in d)
        self.idf = {t: math.log((1 + n) / (1 + c)) + 1 for t, c in df.items()}
        self.vecs = [self._vec(d) for d in self.docs]

    def _vec(self, counts):
        v = {t: c * self.idf.get(t, 1.0) for t, c in counts.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {t: x / norm for t, x in v.items()}

    def query(self, text, k=3):
        q = self._vec(Counter(tokenize(text)))
        scored = []
        for i, v in enumerate(self.vecs):
            s = sum(w * v.get(t, 0.0) for t, w in q.items())
            scored.append((i, s))
        return sorted(scored, key=lambda x: -x[1])[:k]
