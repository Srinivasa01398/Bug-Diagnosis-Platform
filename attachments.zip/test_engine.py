import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from bugdiag.engine import DiagnosisEngine
from bugdiag.store import HistoryStore
from bugdiag.parser import parse

PY = '''Traceback (most recent call last):
  File "app/main.py", line 10, in handler
    name = user.profile.name
  File "app/models.py", line 42, in get_profile
    return re.match(p, s).group(1)
AttributeError: 'NoneType' object has no attribute 'group'
'''
JS = '''TypeError: Cannot read properties of undefined (reading 'map')
    at render (/app/src/List.js:15:22)
    at node_modules/react/index.js:100:5
'''
JAVA = '''Exception in thread "main" java.lang.RuntimeException: wrapper
    at com.acme.Svc.run(Svc.java:21)
Caused by: java.lang.NullPointerException: x is null
    at com.acme.Dao.load(Dao.java:77)
'''

def eng():
    return DiagnosisEngine(HistoryStore(os.path.join(tempfile.mkdtemp(), "h.json")))

class T(unittest.TestCase):
    def test_python(self):
        p = parse(PY)
        self.assertEqual((p.language, p.error_type), ("python", "AttributeError"))
        self.assertEqual(p.app_frame().line, 42)
    def test_js(self):
        p = parse(JS); self.assertEqual(p.language, "javascript")
        self.assertEqual(p.app_frame().file, "/app/src/List.js")
    def test_java_root_cause(self):
        p = parse(JAVA); self.assertEqual(p.error_type, "java.lang.NullPointerException")
    def test_diagnose_rule(self):
        r = eng().diagnose(PY)
        self.assertEqual(r["category"], "null-reference"); self.assertGreaterEqual(r["confidence"], 0.7)
    def test_learning_loop(self):
        e = eng(); raw = "WeirdCustomError: widget frobnicator jammed"
        before = e.diagnose(raw)["confidence"]
        e.learn(raw, "Restart the frobnicator worker.")
        after = e.diagnose("WeirdCustomError: widget frobnicator jammed again")
        self.assertGreater(after["confidence"], before)
        self.assertTrue(any(x["source"] == "history" for x in after["recommendations"]))
    def test_llm_fallback(self):
        e = DiagnosisEngine(HistoryStore(os.path.join(tempfile.mkdtemp(), "h.json")), llm=lambda p: "ai")
        self.assertEqual(e.diagnose("Foo: totally unknown zzz")["ai_suggestion"], "ai")

if __name__ == "__main__":
    unittest.main()
