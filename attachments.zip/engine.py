"""Stage 4 - Orchestration: parse -> rules -> history similarity -> ranked recommendations."""
import re
from .parser import parse, ParsedError
from .knowledge import RULES
from .similarity import TfidfIndex
from .store import HistoryStore


def signature(p: ParsedError) -> str:
    fns = " ".join(f.function for f in p.frames[-3:])
    return f"{p.error_type} {p.message} {fns}"


def build_llm_prompt(p: ParsedError, code_context: str = "") -> str:
    f = p.app_frame()
    where = f"{f.file}:{f.line} in {f.function}" if f else "unknown"
    return (f"You are a debugging assistant. Language: {p.language}.\n"
            f"Error: {p.error_type}: {p.message}\nLocation: {where}\n"
            f"Code:\n{code_context}\nExplain the root cause and give a minimal fix.")


class DiagnosisEngine:
    def __init__(self, store: HistoryStore = None, llm=None):
        self.store = store or HistoryStore()
        self.llm = llm  # optional callable(prompt: str) -> str

    def diagnose(self, raw: str, code_context: str = "") -> dict:
        p = parse(raw)
        haystack = f"{p.error_type}: {p.message}"
        rules = [r for r in RULES if re.search(r.pattern, haystack, re.I)]

        history = self.store.all()
        sims = []
        if history:
            index = TfidfIndex([h["signature"] for h in history])
            sims = [(history[i], s) for i, s in index.query(signature(p), 3) if s >= 0.25]

        # Confidence: transparent, additive heuristic
        best_sim = sims[0][1] if sims else 0.0
        if rules:
            conf = 0.6 + (0.2 if best_sim > 0.5 else 0.0)
        else:
            conf = 0.15 + 0.5 * best_sim
        conf += 0.1 if p.frames else 0.0
        conf = round(min(conf, 0.95), 2)

        recs, seen = [], set()
        for r in rules:
            for fx in r.fixes:
                if fx not in seen:
                    seen.add(fx)
                    recs.append({"fix": fx, "source": "rule", "rule": r.id})
        for h, s in sims:
            if h["fix"] not in seen:
                seen.add(h["fix"])
                recs.append({"fix": h["fix"], "source": "history", "similarity": round(s, 2)})

        f = p.app_frame()
        result = {
            "parsed": p.to_dict(),
            "location": {"file": f.file, "line": f.line, "function": f.function, "code": f.code} if f else None,
            "category": rules[0].category if rules else "unknown",
            "severity": rules[0].severity if rules else "unknown",
            "probable_cause": rules[0].cause if rules else "No known pattern matched; see similar past bugs or AI analysis.",
            "confidence": conf,
            "recommendations": recs,
        }
        if self.llm and conf < 0.6:
            result["ai_suggestion"] = self.llm(build_llm_prompt(p, code_context))
        return result

    def learn(self, raw: str, fix: str):
        """Feedback loop: store a confirmed fix so future similar bugs get it."""
        p = parse(raw)
        self.store.add(signature(p), p.error_type, fix)
