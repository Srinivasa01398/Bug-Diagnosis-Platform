# Intelligent Bug Diagnosis Platform

Paste a stack trace -> get the failing location, probable cause, confidence score and ranked fixes.
Pure Python 3.8+ standard library. No installs needed.

## Run
    python cli.py diagnose trace.txt        # or: cat trace.txt | python cli.py diagnose
    python cli.py serve --port 8000         # JSON API
    python cli.py feedback trace.txt --fix "What fixed it"
    python -m unittest discover -s tests -v

API: POST /diagnose {"log": "...", "code": "optional snippet"} | POST /feedback {"log","fix"} | GET /health

## Architecture (4 stages)
    raw log -> [1 parser] -> ParsedError -> [2 rules] + [3 similarity] -> [4 engine] -> JSON result
                                                                   \-> optional LLM fallback

### 1. parser.py - understanding the log
- Dataclasses `Frame` and `ParsedError` give every language the same shape.
- `parse()` detects language by signature: `Traceback (most recent call last)` / `File "x", line N` = Python;
  `at pkg.Class.method(File.java:N)` = Java; `at fn (file.js:L:C)` = JavaScript. Order matters: Java frames also
  resemble JS frames, so Java is tested first.
- Python: frames are collected with regex; the exception line is found by scanning from the BOTTOM.
- Java: the LAST `Caused by:` is the root cause, so we keep overwriting `root` while looping.
- `app_frame()` walks frames in reverse and skips library code (site-packages, node_modules, java.*) so the
  reported location is YOUR code, not the framework's.

### 2. knowledge.py - expert rules
Each `Rule` = regex + category + severity + cause + ordered fixes. Regex is tested against `"Type: message"`.
Adding knowledge = appending one `Rule`; no other code changes. Rules give high precision on common errors.

### 3. similarity.py + store.py - learning from history
- `normalize()` removes volatile details (numbers, hex addresses, quoted strings, paths) so two occurrences of the
  same bug produce similar text.
- `TfidfIndex` is TF-IDF written by hand: term frequency x inverse document frequency (rare words weigh more),
  L2-normalised, so a dot product equals cosine similarity.
- `HistoryStore` is a JSON file of past bugs + confirmed fixes. Matches under 0.25 similarity are discarded as noise.

### 4. engine.py - decision making
- Runs matching rules, then similarity search, then merges and de-duplicates fixes (rules first, history second).
- Confidence is a transparent heuristic: rule hit = 0.6; +0.2 if a very similar past bug exists; +0.1 if frames
  were parsed; with no rule = 0.15 + 0.5 x best similarity; capped at 0.95 (never claim certainty).
- `learn()` is the feedback loop: a confirmed fix is stored, so the same bug class scores higher next time
  (proved by `test_learning_loop`).
- `llm` is an injected callable `prompt -> text`. It is used only when confidence < 0.6, and
  `build_llm_prompt()` supplies error, location and code. Plug in the Anthropic SDK like this:
      import anthropic; c = anthropic.Anthropic()
      llm = lambda p: c.messages.create(model="claude-sonnet-4-5", max_tokens=800,
                messages=[{"role":"user","content":p}]).content[0].text
      DiagnosisEngine(llm=llm)
  (Check the current model name in Anthropic's docs.)

### server.py / cli.py
`http.server` handler factory closes over one engine; bad JSON or missing keys return 400. CLI wraps the same engine.

## Extending
- New language: add a `_parse_x()` in parser.py and a detection branch in `parse()`.
- Better retrieval: replace TfidfIndex with embeddings; keep `query(text,k)` signature.
- Production: swap JSON for SQLite/Postgres, add auth to the API, redact secrets from logs before storing.
