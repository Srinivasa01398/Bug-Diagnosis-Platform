import argparse, json, sys
from bugdiag.engine import DiagnosisEngine
from bugdiag.server import serve


def main():
    ap = argparse.ArgumentParser(description="Intelligent Bug Diagnosis Platform")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("diagnose"); d.add_argument("file", nargs="?", default="-")
    s = sub.add_parser("serve"); s.add_argument("--port", type=int, default=8000)
    f = sub.add_parser("feedback"); f.add_argument("file"); f.add_argument("--fix", required=True)
    a = ap.parse_args()
    eng = DiagnosisEngine()
    if a.cmd == "diagnose":
        raw = sys.stdin.read() if a.file == "-" else open(a.file).read()
        r = eng.diagnose(raw)
        print(f"\n{r['parsed']['error_type']}: {r['parsed']['message']}")
        if r["location"]:
            l = r["location"]; print(f"At {l['file']}:{l['line']} ({l['function']})  {l['code']}")
        print(f"Category: {r['category']} | Severity: {r['severity']} | Confidence: {r['confidence']}")
        print(f"Cause: {r['probable_cause']}\nFixes:")
        for i, x in enumerate(r["recommendations"], 1):
            print(f"  {i}. [{x['source']}] {x['fix']}")
    elif a.cmd == "serve":
        serve(a.port, eng)
    else:
        eng.learn(open(a.file).read(), a.fix); print("Saved.")

if __name__ == "__main__":
    main()
