"""Tiny JSON API using only the standard library."""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from .engine import DiagnosisEngine


def make_handler(engine):
    class H(BaseHTTPRequestHandler):
        def _send(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            self._send(200, {"status": "ok"}) if self.path == "/health" else self._send(404, {"error": "not found"})

        def do_POST(self):
            try:
                data = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
                if self.path == "/diagnose":
                    return self._send(200, engine.diagnose(data["log"], data.get("code", "")))
                if self.path == "/feedback":
                    engine.learn(data["log"], data["fix"])
                    return self._send(201, {"saved": True})
                self._send(404, {"error": "not found"})
            except (KeyError, json.JSONDecodeError) as e:
                self._send(400, {"error": f"bad request: {e}"})

        def log_message(self, *a):
            pass
    return H


def serve(port=8000, engine=None):
    engine = engine or DiagnosisEngine()
    print(f"Listening on http://localhost:{port}")
    HTTPServer(("0.0.0.0", port), make_handler(engine)).serve_forever()
