"""Stage 1 - Parsing: turn a raw stack trace / log into a structured ParsedError."""
import re
from dataclasses import dataclass, field, asdict


@dataclass
class Frame:
    file: str
    line: int
    function: str
    code: str = ""


@dataclass
class ParsedError:
    language: str
    error_type: str
    message: str
    frames: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)

    def app_frame(self):
        """Most relevant frame = last frame that is NOT library code."""
        lib_markers = ("site-packages", "node_modules", "/usr/lib", "java.", "javax.", "sun.", "<frozen")
        for f in reversed(self.frames):
            if not any(m in f.file or m in f.function for m in lib_markers):
                return f
        return self.frames[-1] if self.frames else None


PY_FRAME = re.compile(r'File "(?P<file>[^"]+)", line (?P<line>\d+), in (?P<fn>\S+)')
PY_EXC = re.compile(r'^(?P<type>[A-Za-z_][\w.]*(?:Error|Exception|Exit|Interrupt))\s*(?::\s*(?P<msg>.*))?$')
JS_EXC = re.compile(r'^(?:Uncaught\s+)?(?P<type>[A-Za-z]*Error)\s*:\s*(?P<msg>.*)$')
JS_FRAME = re.compile(r'at\s+(?:(?P<fn>[^\s(]+)\s+)?\(?(?P<file>[^():\s]+):(?P<line>\d+):\d+\)?')
JAVA_EXC = re.compile(r'^(?P<type>[a-z][\w.]*\.[A-Z]\w*(?:Exception|Error))\s*(?::\s*(?P<msg>.*))?$')
JAVA_FRAME = re.compile(r'at\s+(?P<fn>[\w.$<>]+)\((?P<file>[\w.]+):(?P<line>\d+)\)')


def _parse_python(lines):
    frames = []
    for i, ln in enumerate(lines):
        m = PY_FRAME.search(ln)
        if m:
            code = ""
            if i + 1 < len(lines) and not PY_FRAME.search(lines[i + 1]):
                code = lines[i + 1].strip()
            frames.append(Frame(m["file"], int(m["line"]), m["fn"], code))
    for ln in reversed(lines):  # exception line is at the bottom
        m = PY_EXC.match(ln.strip())
        if m:
            return ParsedError("python", m["type"], (m["msg"] or "").strip(), frames)
    return ParsedError("python", "UnknownError", "", frames)


def _parse_java(lines):
    frames = [Frame(m["file"], int(m["line"]), m["fn"])
              for ln in lines if (m := JAVA_FRAME.search(ln))]
    root = None
    for ln in lines:  # last "Caused by" wins: it is the root cause
        s = ln.strip()
        if s.startswith("Caused by:"):
            s = s[len("Caused by:"):].strip()
        s = re.sub(r'^Exception in thread "[^"]+"\s+', "", s)
        m = JAVA_EXC.match(s)
        if m:
            root = m
    if root:
        return ParsedError("java", root["type"], (root["msg"] or "").strip(), frames)
    return ParsedError("java", "UnknownException", "", frames)


def _parse_js(lines):
    frames = [Frame(m["file"], int(m["line"]), m["fn"] or "<anonymous>")
              for ln in lines if (m := JS_FRAME.search(ln))]
    for ln in lines:
        m = JS_EXC.match(ln.strip())
        if m:
            return ParsedError("javascript", m["type"], m["msg"].strip(), frames)
    return ParsedError("javascript", "UnknownError", "", frames)


def parse(raw: str) -> ParsedError:
    lines = [l.rstrip() for l in raw.strip().splitlines() if l.strip()]
    if not lines:
        return ParsedError("unknown", "EmptyInput", "")
    if "Traceback (most recent call last)" in raw or PY_FRAME.search(raw):
        return _parse_python(lines)
    if JAVA_FRAME.search(raw):
        return _parse_java(lines)
    if JS_FRAME.search(raw) or JS_EXC.match(lines[0].strip()):
        return _parse_js(lines)
    # Fallback: a bare one-line error message like "KeyError: 'id'"
    last = lines[-1].strip()
    m = re.match(r"^(?P<type>[\w.]+)\s*:\s*(?P<msg>.*)$", last)
    if m:
        return ParsedError("unknown", m["type"], m["msg"])
    return ParsedError("unknown", "UnknownError", last)
