"""Persistent history of resolved bugs (JSON file). This is the platform's 'memory'."""
import json
import os
import time

SEED = [
    {"signature": "KeyError QUOTED user payload missing field", "error_type": "KeyError",
     "fix": "Payload schema changed; read with .get() and validate input at the API boundary."},
    {"signature": "AttributeError NoneType object has no attribute regex match",
     "error_type": "AttributeError", "fix": "re.match returned None; check the match before using .group()."},
    {"signature": "Cannot read properties of undefined reading map react state",
     "error_type": "TypeError", "fix": "State initialised as undefined; initialise it to [] and use optional chaining."},
]


class HistoryStore:
    def __init__(self, path="history.json"):
        self.path = path
        if not os.path.exists(path):
            self._save(SEED)

    def _save(self, items):
        with open(self.path, "w") as f:
            json.dump(items, f, indent=2)

    def all(self):
        with open(self.path) as f:
            return json.load(f)

    def add(self, signature, error_type, fix):
        items = self.all()
        items.append({"signature": signature, "error_type": error_type, "fix": fix, "ts": int(time.time())})
        self._save(items)
